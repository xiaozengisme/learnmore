-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2015-07-21 18:07:59
-- 服务器版本： 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `guizu_nntzd_com`
--
CREATE DATABASE IF NOT EXISTS `guizu_nntzd_com` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `guizu_nntzd_com`;

-- --------------------------------------------------------

--
-- 表的结构 `guizu_activity`
--

CREATE TABLE IF NOT EXISTS `guizu_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '//活动名称',
  `cover` varchar(255) NOT NULL COMMENT '//图片',
  `btime` int(11) NOT NULL COMMENT '//开始时间',
  `etime` int(11) NOT NULL COMMENT '//结束时间',
  `address` varchar(255) NOT NULL COMMENT '//地址',
  `detail` longtext NOT NULL COMMENT '//详情',
  `sort` int(11) NOT NULL COMMENT '//排序',
  `hits` int(11) NOT NULL COMMENT '//点击量',
  `status` int(11) NOT NULL COMMENT '//状态',
  `atime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='//活动' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `guizu_activity`
--

INSERT INTO `guizu_activity` (`id`, `name`, `cover`, `btime`, `etime`, `address`, `detail`, `sort`, `hits`, `status`, `atime`) VALUES
(1, '活动名称', 'no cover', 1437473123, 1437473123, '竹溪大道', 'hello world', 1, 111, 1, 1437473123);

-- --------------------------------------------------------

--
-- 表的结构 `guizu_coin_rate`
--

CREATE TABLE IF NOT EXISTS `guizu_coin_rate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gid` int(11) NOT NULL COMMENT '//gid',
  `rate` decimal(3,2) NOT NULL COMMENT '//比例',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='//游戏币积分比率' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `guizu_coin_rate`
--

INSERT INTO `guizu_coin_rate` (`id`, `gid`, `rate`) VALUES
(1, 1, '1.20');

-- --------------------------------------------------------

--
-- 表的结构 `guizu_community`
--

CREATE TABLE IF NOT EXISTS `guizu_community` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section` int(11) NOT NULL COMMENT '//版块 1高校 2所有游戏的排行榜 3游戏社区',
  `name` varchar(255) NOT NULL COMMENT '//圈子名称',
  `icon` varchar(255) NOT NULL COMMENT '//图标',
  `atime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='//圈子' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `guizu_community`
--

INSERT INTO `guizu_community` (`id`, `section`, `name`, `icon`, `atime`) VALUES
(1, 1, '南宁斗地主', 'no icon', 1437472837);

-- --------------------------------------------------------

--
-- 表的结构 `guizu_friends`
--

CREATE TABLE IF NOT EXISTS `guizu_friends` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ask_uid` int(11) NOT NULL COMMENT '//发出请求的uid',
  `recieve_uid` int(11) NOT NULL COMMENT '//接受的uid',
  `status` int(11) NOT NULL COMMENT '//好友状态0没接受1好友关系',
  `send_time` int(11) NOT NULL COMMENT '//发送请求时间',
  `accept_time` int(11) NOT NULL COMMENT '//接受时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `guizu_friends`
--

INSERT INTO `guizu_friends` (`id`, `ask_uid`, `recieve_uid`, `status`, `send_time`, `accept_time`) VALUES
(1, 1, 2, 0, 1437473163, 0);

-- --------------------------------------------------------

--
-- 表的结构 `guizu_game`
--

CREATE TABLE IF NOT EXISTS `guizu_game` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '//名称',
  `icon` varchar(255) NOT NULL COMMENT '//图标',
  `pic` varchar(255) NOT NULL COMMENT '//详情图片',
  `type` int(11) NOT NULL COMMENT '//类型',
  `size` varchar(255) NOT NULL COMMENT '//大小',
  `dtimes` int(11) NOT NULL COMMENT '//下载次数',
  `abstr` longtext NOT NULL COMMENT '//简介',
  `carousel` text NOT NULL COMMENT '//轮换图',
  `atime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='//游戏' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `guizu_game`
--

INSERT INTO `guizu_game` (`id`, `name`, `icon`, `pic`, `type`, `size`, `dtimes`, `abstr`, `carousel`, `atime`) VALUES
(1, '南宁斗地主', 'no icon', 'no pic', 1, '100M', 1437473237, 'hello world', 'pic1|pic2|pic3', 1437473237);

-- --------------------------------------------------------

--
-- 表的结构 `guizu_location`
--

CREATE TABLE IF NOT EXISTS `guizu_location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '//区域名称',
  `pid` int(11) NOT NULL COMMENT '//父id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='//区域表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `guizu_maker`
--

CREATE TABLE IF NOT EXISTS `guizu_maker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL COMMENT '//标题',
  `icon` varchar(255) NOT NULL COMMENT '//图片',
  `des` varchar(255) NOT NULL COMMENT '//描述',
  `detail` longtext NOT NULL COMMENT '//详情',
  `sort` int(11) NOT NULL COMMENT '//排序',
  `hits` int(11) NOT NULL COMMENT '//点击量',
  `status` tinyint(1) NOT NULL COMMENT '//状态',
  `atime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='//赚客吧' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `guizu_msg`
--

CREATE TABLE IF NOT EXISTS `guizu_msg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL COMMENT '//谁发的、消息类型',
  `to_id` int(11) NOT NULL COMMENT '//发给谁',
  `msg_title` varchar(255) NOT NULL COMMENT '//消息标题',
  `msg_content` text NOT NULL COMMENT '//消息内容',
  `status` tinyint(1) NOT NULL COMMENT '//状态：已读未读',
  `atime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='//消息' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `guizu_photos`
--

CREATE TABLE IF NOT EXISTS `guizu_photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '//uid',
  `url` varchar(255) NOT NULL COMMENT '//图片地址',
  `atime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='//图片表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `guizu_photos_zan`
--

CREATE TABLE IF NOT EXISTS `guizu_photos_zan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fuid` int(11) NOT NULL COMMENT '//点赞人id',
  `atime` int(11) NOT NULL COMMENT '//点赞时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='//图片点赞' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `guizu_post`
--

CREATE TABLE IF NOT EXISTS `guizu_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL COMMENT '//社区id',
  `uid` int(11) NOT NULL COMMENT '//uid',
  `title` int(11) NOT NULL COMMENT '//标题',
  `content` text NOT NULL COMMENT '//内容',
  `pics` text NOT NULL COMMENT '//图片，多张图片用|线分割',
  `status` int(11) NOT NULL COMMENT '//帖子状态',
  `atime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='//帖子' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `guizu_shop`
--

CREATE TABLE IF NOT EXISTS `guizu_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '//商品名称',
  `pic` varchar(255) NOT NULL COMMENT '//图片',
  `unit` int(11) NOT NULL COMMENT '//单位：游戏币、积分、点数',
  `needs` int(11) NOT NULL COMMENT '//所需金额',
  `atime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='//商城' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `guizu_shop`
--

INSERT INTO `guizu_shop` (`id`, `name`, `pic`, `unit`, `needs`, `atime`) VALUES
(1, '5000游戏币', 'no pic', 1, 5000, 1437471958);

-- --------------------------------------------------------

--
-- 表的结构 `guizu_users`
--

CREATE TABLE IF NOT EXISTS `guizu_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) NOT NULL COMMENT '//帐号',
  `nickname` varchar(255) CHARACTER SET utf8mb4 NOT NULL COMMENT '//昵称',
  `passwd` varchar(255) NOT NULL COMMENT '//密码',
  `avatar` varchar(255) NOT NULL COMMENT '//头像',
  `sex` tinyint(1) NOT NULL COMMENT '//性别0保密1男2女',
  `belong_to` int(11) NOT NULL COMMENT '//所属区域、学校',
  `invite_code` varchar(8) NOT NULL COMMENT '//邀请码',
  `status` tinyint(11) NOT NULL COMMENT '//用户状态',
  `score` int(11) NOT NULL COMMENT '//积分',
  `point` int(11) NOT NULL COMMENT '//点数',
  `vip` tinyint(1) NOT NULL DEFAULT '0' COMMENT '//是否vip0否1是',
  `strange_msg` tinyint(1) NOT NULL DEFAULT '1' COMMENT '//是否接受陌生消息',
  `sys_msg` tinyint(1) NOT NULL DEFAULT '1' COMMENT '//是否接受系统消息',
  `atime` int(11) NOT NULL COMMENT '//注册时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `guizu_users`
--

INSERT INTO `guizu_users` (`id`, `account`, `nickname`, `passwd`, `avatar`, `sex`, `belong_to`, `invite_code`, `status`, `score`, `point`, `vip`, `strange_msg`, `sys_msg`, `atime`) VALUES
(1, 'ucmxzz', 'ucmxzz', '313313', 'no avatar', 1, 1, '10101010', 1, 999, 999, 1, 1, 1, 1437472086);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
