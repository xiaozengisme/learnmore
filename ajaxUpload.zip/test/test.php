<?php
// sleep(1000);
$imgArr = getimagesize($_FILES['avatar']['tmp_name']);

if(!in_array($imgArr[2], array(2,3))){
	die(json_encode(array('status'=>0, 'errMsg'=>'图片格式不对')));
}

if($_FILES['avatar']['size'] > 2000000){
	die(json_encode(array('status'=>0, 'errMsg'=>'图片太大')));
}

if ($_FILES["avatar"]["error"] > 0){
	die(json_encode(array('status'=>0, 'errMsg'=>'错误代码：'.$_FILES["file"]["error"])));
}
$ext = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
$newPath = getRandStr(10).'.'.$ext;

if(move_uploaded_file($_FILES["avatar"]["tmp_name"], $newPath)){
	die(json_encode(array('status'=>1, 'filepath'=>$newPath)));
}else{
	die(json_encode(array('status'=>0, 'errMsg'=>'错误')));
}

function getRandStr($len){
	$num = range(0,9);
	shuffle($num);
	$output = '';
	for ($i=0; $i < $len; $i++) {
		$output .= $num[mt_rand(0,9)];
	}
	return $output;
}		

